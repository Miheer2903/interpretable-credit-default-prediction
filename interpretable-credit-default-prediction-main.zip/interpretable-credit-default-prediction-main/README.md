# interpretable-credit-default-prediction
Credit Default Prediction on the Amex Dataset along with Model Interpretability

- Create virtualenv using `virtualenv venv` 
- activate the virtual env 
- Install required libraries using `pip install -r requirements.txt` 
- start working 
